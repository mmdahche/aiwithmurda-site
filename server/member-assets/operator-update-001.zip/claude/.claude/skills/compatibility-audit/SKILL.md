---
name: compatibility-audit
description: Checks whether an Operator Toolkit release remains compatible with current Claude Code, Codex, project, and platform behavior.
---

# Compatibility Audit

Category: Update Channel

## Workflow

1. Read the release notes and current official documentation for changed surfaces.
2. Compare instruction files, skill locations, commands, permissions, and deprecated behavior.
3. Run install and read-only invocation checks in a disposable project.
4. Record required migrations, unsupported states, and safe fallbacks.
5. Update the compatibility matrix with evidence and review date.

## Return

- Reviewed versions
- Compatibility result
- Breaking changes
- Migration
- Fallback
- Evidence date

## Guardrails

- Do not infer compatibility from version numbers alone.
- Do not test updates in a production project first.
- Use official sources for current behavior.
