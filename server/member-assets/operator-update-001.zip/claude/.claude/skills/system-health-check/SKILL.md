---
name: system-health-check
description: Checks whether the installed operator system is still coherent after tool, project, or workflow changes.
---

# System Health Check

Category: Update Channel

## Workflow

1. Verify agent versions, authentication, project root, instruction loading, and Git state.
2. Check skill inventory for duplicates, broken references, broad triggers, and stale commands.
3. Run one foundation, one build, and one verification workflow.
4. Inspect recent failures and handoffs for repeated system friction.
5. Recommend one repair or cleanup at a time and record the new baseline.

## Return

- Environment health
- Instruction health
- Skill health
- Workflow checks
- Repair priority
- New baseline

## Guardrails

- Do not rewrite a healthy setup for novelty.
- Do not remove files without ownership evidence.
- Keep repairs reversible.
