---
name: skill-upgrade-review
description: Reviews a new or changed skill before replacing a working installed version.
---

# Skill Upgrade Review

Category: Update Channel

## Workflow

1. Diff the installed and candidate skill plus every referenced file or script.
2. Classify changes as instruction, capability, dependency, permission, output, or guardrail changes.
3. Identify project-specific customization that must be preserved.
4. Test explicit and natural-language triggers in a disposable project.
5. Approve, revise, or reject with rollback instructions.

## Return

- Diff summary
- Behavior change
- Customization to preserve
- Test evidence
- Decision
- Rollback

## Guardrails

- Never overwrite without a backup.
- Inspect scripts before execution.
- Do not install a skill only because it is newer.
