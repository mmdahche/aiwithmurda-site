---
name: release-migration
description: Applies an Operator Toolkit release as a staged, reversible migration.
---

# Release Migration

Category: Update Channel

## Workflow

1. Confirm current version, target version, release checksum, and backup location.
2. Read additions, changes, removals, compatibility notes, and project impact.
3. Apply files in a disposable or branch-isolated environment first.
4. Run the release verification checklist and one real workflow.
5. Promote the update or restore the saved baseline and record the result.

## Return

- Version path
- Backup
- Files changed
- Verification
- Promotion or rollback
- Release receipt

## Guardrails

- Do not skip versions without reading migration notes.
- Do not delete customized files automatically.
- Never update without a restore point.
