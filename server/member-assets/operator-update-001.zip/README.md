# Operator System Founding Update 001

Version: 1.1.0

This is an update pack. Read RELEASE.md, compare installed files, and create a restore point before replacing anything.

## Install deliberately

- Claude Code project skills: copy selected folders from `claude/.claude/skills/` into your project's `.claude/skills/` directory.
- Codex project skills: copy selected folders from `codex/.agents/skills/` into your project's `.agents/skills/` directory.
- Read every SKILL.md before installation.
- Install only the collections tied to repeated work.
- Back up customized skills before an update.
- Never copy secret files, credentials, or machine-specific paths into a skill.

## Included skills

- Compatibility Audit (compatibility-audit) - Update Channel
- Skill Upgrade Review (skill-upgrade-review) - Update Channel
- Release Migration (release-migration) - Update Channel
- System Health Check (system-health-check) - Update Channel
