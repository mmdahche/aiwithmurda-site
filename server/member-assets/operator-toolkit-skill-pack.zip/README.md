# The Operator Toolkit - 24-Skill Installation Pack

Version: 1.0.0

This pack contains the same customer-safe skills in Claude Code and Codex project-folder layouts.

## Install deliberately

- Claude Code project skills: copy selected folders from `claude/.claude/skills/` into your project's `.claude/skills/` directory.
- Codex project skills: copy selected folders from `codex/.agents/skills/` into your project's `.agents/skills/` directory.
- Read every SKILL.md before installation.
- Install only the collections tied to repeated work.
- Back up customized skills before an update.
- Never copy secret files, credentials, or machine-specific paths into a skill.

## Included skills

- Project Map (project-map) - Foundation + Scope
- Requirement Brief (requirement-brief) - Foundation + Scope
- Build One Slice (build-one-slice) - Foundation + Scope
- Environment Audit (environment-audit) - Foundation + Scope
- Scope Guard (scope-guard) - Foundation + Scope
- Context Handoff (context-handoff) - Foundation + Scope
- Debug Loop (debug-loop) - Build + Quality
- User Path Test (user-path-test) - Build + Quality
- Code Review (code-review) - Build + Quality
- Safe Deploy (safe-deploy) - Build + Quality
- Migration Guard (migration-guard) - Build + Quality
- Dependency Decision (dependency-decision) - Build + Quality
- Verify Before Done (verify-before-done) - Build + Quality
- Information Architecture (information-architecture) - Design + Product
- UI Critique (ui-critique) - Design + Product
- Responsive QA (responsive-qa) - Design + Product
- Accessibility Pass (accessibility-pass) - Design + Product
- Product Copy Review (product-copy-review) - Design + Product
- Workflow Automation Brief (workflow-automation-brief) - Operations + Growth
- SOP Builder (sop-builder) - Operations + Growth
- Research Brief (research-brief) - Operations + Growth
- Offer Builder (offer-builder) - Operations + Growth
- Launch Checklist (launch-checklist) - Operations + Growth
- Weekly Operator Review (weekly-operator-review) - Operations + Growth
