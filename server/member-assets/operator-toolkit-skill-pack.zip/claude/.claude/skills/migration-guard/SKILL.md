---
name: migration-guard
description: Reviews database and data-shape changes for compatibility and recovery. Use before schema changes, backfills, renamed keys, or curriculum migrations.
---

# Migration Guard

Category: Build + Quality

## Workflow

1. Map current readers, writers, constraints, policies, and existing data states.
2. Define forward migration, compatibility window, backfill, and rollback behavior.
3. Test idempotency and old-row handling with realistic fixtures.
4. Verify permissions, indexes, deletion behavior, and application deploy order.
5. Record post-migration checks and the condition that triggers rollback.

## Return

- Current contract
- Migration plan
- Compatibility behavior
- Rollback
- Verification queries
- Residual risk

## Guardrails

- Never destroy old data by default.
- Do not assume empty production tables.
- Do not couple rollback to unavailable code.
