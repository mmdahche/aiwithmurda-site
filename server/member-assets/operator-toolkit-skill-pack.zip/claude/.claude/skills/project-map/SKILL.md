---
name: project-map
description: Maps an unfamiliar project before implementation. Use when the user asks where a feature lives, how a request flows, or which files should change.
---

# Project Map

Category: Foundation + Scope

## Workflow

1. Read the nearest project guidance, package scripts, and entry points without editing.
2. Identify runtime boundaries, data stores, external services, and protected paths.
3. Trace the requested user or data flow through the smallest relevant file set.
4. Verify the real development, test, and build commands from project files.
5. Separate confirmed facts from assumptions and recommend the next inspection.

## Return

- Project purpose
- Relevant file map
- User or request flow
- Verified commands
- Risks and unknowns

## Guardrails

- Do not edit files.
- Do not install dependencies.
- Do not invent commands or architecture.
