---
name: user-path-test
description: Verifies the real user workflow instead of isolated implementation details. Use after a feature, fix, payment, authentication, or responsive change.
---

# User Path Test

Category: Build + Quality

## Workflow

1. Name the user, starting state, action sequence, and visible success state.
2. Prepare realistic safe test data and required viewport or device states.
3. Run the path from a clean start without hidden developer shortcuts.
4. Capture errors, layout problems, persistence, loading, empty, and recovery states.
5. Record evidence and rerun after fixes.

## Return

- Path tested
- Environment
- Evidence
- Failures
- Retest result
- Untested states

## Guardrails

- Do not use production customer data.
- Do not skip authentication or payment boundaries.
- Delete disposable test data.
