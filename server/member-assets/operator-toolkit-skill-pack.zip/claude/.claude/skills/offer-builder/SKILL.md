---
name: offer-builder
description: Turns a real capability into a clear, deliverable offer. Use when defining tiers, outcomes, pricing boundaries, bonuses, and recurring value.
---

# Offer Builder

Category: Operations + Growth

## Workflow

1. Name the buyer, painful current state, desired result, and evidence that the method works.
2. Define the mechanism, deliverables, access period, support, ownership, and exclusions.
3. Separate entry, implementation, and recurring value so tiers do not cannibalize each other.
4. Price against transformation and delivery burden, then compare current alternatives.
5. Write transparent purchase, renewal, cancellation, and refund expectations.

## Return

- Buyer
- Promise
- Mechanism
- Deliverables
- Tier ladder
- Price rationale
- Disclosure

## Guardrails

- Do not sell private or unlicensed assets.
- Do not use file count as the only value claim.
- Do not hide recurring billing.
