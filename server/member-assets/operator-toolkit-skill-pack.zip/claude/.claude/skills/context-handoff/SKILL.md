---
name: context-handoff
description: Creates a reproducible handoff between people or AI agents. Use before pausing, changing tools, or moving a task to another operator.
---

# Context Handoff

Category: Foundation + Scope

## Workflow

1. State the original objective and the current observable state.
2. List decisions, files changed, commands run, and evidence captured.
3. Separate completed work from open threads and known limits.
4. Name the exact next action and the file or command where work resumes.
5. Remove secrets, private data, and irrelevant transcript history.

## Return

- Objective
- Current state
- Decisions
- Files and checks
- Open threads
- Exact next action

## Guardrails

- Never include credentials.
- Do not claim checks that were not run.
- Keep the handoff reproducible and concise.
