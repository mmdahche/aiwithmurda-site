---
name: research-brief
description: Produces decision-ready research with current sources and explicit inference. Use before product, market, pricing, technical, or operational decisions.
---

# Research Brief

Category: Operations + Growth

## Workflow

1. Define the decision, deadline, audience, criteria, and what would change the answer.
2. Separate stable project facts from facts that require current external verification.
3. Prioritize primary sources and gather comparable evidence rather than isolated examples.
4. Distinguish source claims, calculations, assumptions, and inference.
5. Recommend an action with uncertainty, tradeoffs, and a verification date.

## Return

- Decision
- Criteria
- Evidence
- Comparison
- Inference
- Recommendation
- Uncertainty

## Guardrails

- Do not fabricate citations.
- Do not treat search snippets as full evidence.
- Browse when facts may have changed.
