---
name: accessibility-pass
description: Runs a practical accessibility review of a user path. Use before shipping forms, navigation, dialogs, media, dashboards, or interactive tools.
---

# Accessibility Pass

Category: Design + Product

## Workflow

1. Navigate the complete path with keyboard only and inspect focus order and visibility.
2. Verify headings, landmarks, labels, names, descriptions, and state announcements.
3. Check color contrast, non-color status cues, zoom, reduced motion, and text resizing.
4. Test errors, required fields, disabled controls, and recovery without a pointer.
5. Run available automated checks, then document manual coverage and remaining gaps.

## Return

- Keyboard result
- Semantic result
- Visual result
- Form and error result
- Automated findings
- Remaining gaps

## Guardrails

- Automated checks are not complete coverage.
- Do not remove focus outlines.
- Do not use placeholder text as the only label.
