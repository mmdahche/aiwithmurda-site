---
name: safe-deploy
description: Prepares and verifies a production deployment with rollback discipline. Use before and after shipping a live change.
---

# Safe Deploy

Category: Build + Quality

## Workflow

1. Confirm the intended commit, clean working tree, environment, migration order, and owner approval.
2. Run required builds, tests, and preflight user paths.
3. Identify irreversible actions, backups, rollback command, and health signals.
4. Deploy through the project's approved path and monitor until terminal status.
5. Verify the live user path, record the deployed commit, and stop on regression.

## Return

- Preflight
- Deploy target
- Rollback plan
- Live verification
- Commit and status
- Follow-up

## Guardrails

- No force push.
- No production migration without backup and review.
- Never expose environment values in logs.
