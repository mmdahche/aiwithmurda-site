---
name: environment-audit
description: Audits an AI-assisted development environment before setup changes. Use when installing Claude Code, Codex, project rules, skills, or automation.
---

# Environment Audit

Category: Foundation + Scope

## Workflow

1. Identify operating system, shell, Git state, agent surfaces, and project root.
2. Record versions and authentication state without exposing credentials.
3. Locate existing instruction, skill, environment, and ignore files.
4. Flag duplicate guidance, broad access, missing secret protection, and unverified commands.
5. Recommend a staged setup with a rollback checkpoint.

## Return

- Environment receipt
- Existing configuration
- Security gaps
- Compatibility risks
- Staged install plan

## Guardrails

- Never print secret values.
- Do not modify home-level configuration automatically.
- Do not approve broad permissions.
