---
name: sop-builder
description: Turns a repeatable process into an executable standard operating procedure. Use after a workflow has been performed and verified at least once.
---

# SOP Builder

Category: Operations + Growth

## Workflow

1. Define purpose, owner, trigger, prerequisites, and completion evidence.
2. Write the happy path as numbered actions with exact tools and decision points.
3. Add exceptions, approvals, security boundaries, and escalation conditions.
4. Include templates, screenshots, commands, or links without embedding secrets.
5. Test the SOP with a second operator and revise ambiguous steps.

## Return

- Purpose and owner
- Prerequisites
- Procedure
- Exceptions
- Evidence
- Review cadence

## Guardrails

- Do not document an unverified process as standard.
- Do not encode one person's hidden context.
- Keep credentials external.
