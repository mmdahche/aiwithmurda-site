---
name: responsive-qa
description: Verifies a frontend across desktop and mobile viewports. Use after layout, navigation, typography, card, modal, or media changes.
---

# Responsive QA

Category: Design + Product

## Workflow

1. Choose representative mobile, tablet, laptop, and wide desktop viewports.
2. Check horizontal overflow, clipping, overlap, fixed elements, touch targets, and text wrapping.
3. Verify navigation and every primary action remain visible and reachable.
4. Capture full-page screenshots and inspect dynamic, long, empty, and authenticated states.
5. Rerun after fixes and record viewport-specific evidence.

## Return

- Viewports
- Overflow result
- Navigation result
- Visual findings
- Screenshots
- Retest

## Guardrails

- Do not rely on browser resizing alone.
- Do not hide overflow without fixing usability.
- Keep fixed-format controls dimensionally stable.
