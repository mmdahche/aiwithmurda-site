---
name: code-review
description: Reviews a change for behavioral risk and missing proof. Use before merge, deploy, or handoff.
---

# Code Review

Category: Build + Quality

## Workflow

1. Read the request, definition of done, project guidance, and complete diff.
2. Trace changed user, data, auth, billing, and external-service paths.
3. Look for regressions, unsafe assumptions, stale contracts, secret exposure, and missing errors.
4. Check whether tests exercise behavior rather than only implementation.
5. Report findings by severity with file references and concrete fixes.

## Return

- Findings by severity
- Why each matters
- File references
- Missing coverage
- Residual risk

## Guardrails

- Do not lead with style preferences.
- Do not invent failures.
- Say clearly when no issue was found.
