---
name: scope-guard
description: Detects and stops scope drift during implementation. Use when new ideas, refactors, or dependencies appear inside an active task.
---

# Scope Guard

Category: Foundation + Scope

## Workflow

1. Restate the approved outcome, non-goals, and current stop condition.
2. Classify each proposed addition as required, risk reduction, or deferred improvement.
3. Measure whether the addition changes data, auth, billing, infrastructure, or shared contracts.
4. Keep only work required to complete or safely verify the approved outcome.
5. Write a deferred list with rationale instead of silently expanding scope.

## Return

- Scope decision
- Required work
- Deferred work
- Changed risk
- Updated stop condition

## Guardrails

- Do not use polish as a reason to rewrite working systems.
- Do not hide required migration work.
- Escalate irreversible changes.
