---
name: weekly-operator-review
description: Reviews one week of work to improve the operating system. Use after a build cycle, launch week, client delivery, or repeated workflow.
---

# Weekly Operator Review

Category: Operations + Growth

## Workflow

1. Collect shipped outcomes, revenue or pipeline movement, user evidence, failures, and time spent.
2. Identify repeated friction, unnecessary decisions, missing skills, and automation candidates.
3. Review which instructions or workflows helped and which created noise.
4. Choose one system change, one next build, and one thing to stop.
5. Version the changed system and define proof for the next review.

## Return

- Outcomes
- Evidence
- Friction
- System changes
- Next build
- Stop list
- Next review proof

## Guardrails

- Do not confuse activity with outcomes.
- Do not change many system parts at once.
- Preserve the previous working version.
