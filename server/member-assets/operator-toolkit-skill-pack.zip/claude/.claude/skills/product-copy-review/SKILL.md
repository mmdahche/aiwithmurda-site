---
name: product-copy-review
description: Reviews interface and offer copy for clarity, truth, and action. Use on pricing, checkout, onboarding, member, error, and completion states.
---

# Product Copy Review

Category: Design + Product

## Workflow

1. Identify the reader, their current state, expected decision, and likely objection.
2. Verify every promise against actual product behavior and entitlement rules.
3. Replace vague claims with observable outcomes, exact access, timing, and limitations.
4. Clarify price, renewal, cancellation, ownership, and recovery near the decision.
5. Tighten labels and calls to action without removing necessary disclosure.

## Return

- Audience
- Truth gaps
- Confusing copy
- Rewritten copy
- Disclosure checklist

## Guardrails

- Do not manufacture urgency or proof.
- Do not hide recurring charges.
- Do not promise private or unbuilt deliverables.
