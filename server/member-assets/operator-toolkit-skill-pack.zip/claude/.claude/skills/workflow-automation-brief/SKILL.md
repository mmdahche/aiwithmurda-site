---
name: workflow-automation-brief
description: Maps a manual workflow into an automation-ready specification. Use before choosing n8n, APIs, scripts, agents, or integrations.
---

# Workflow Automation Brief

Category: Operations + Growth

## Workflow

1. Document the trigger, inputs, actors, decisions, outputs, and current handoffs.
2. Identify repetitive work, failure states, sensitive data, and human approval points.
3. Separate deterministic steps from judgment that should remain human or agent-assisted.
4. Define the smallest automation slice, observability, retry, and rollback behavior.
5. Specify test fixtures and a manual fallback before choosing tools.

## Return

- Current workflow
- Automation boundary
- Data and approvals
- Failure handling
- MVP
- Verification and fallback

## Guardrails

- Do not automate unclear decisions.
- Do not expose credentials in workflow exports.
- Do not remove human approval from high-impact actions.
