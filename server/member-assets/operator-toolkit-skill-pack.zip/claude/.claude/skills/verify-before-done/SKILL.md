---
name: verify-before-done
description: Verifies a completed change through the real user path. Use after implementation and before commit, deployment, or handoff.
---

# Verify Before Done

Category: Build + Quality

## Workflow

1. Re-read the request and definition of done.
2. Inspect the diff for unrelated edits, secrets, debug output, and generated noise.
3. Run focused tests and broader checks required by project guidance.
4. Exercise the real browser, app, API, terminal, or payment path.
5. Record evidence, untested areas, and a ready or not-ready decision.

## Return

- Checks run
- User path
- Evidence
- Missing coverage
- Remaining risk
- Readiness decision

## Guardrails

- Never report an unrun check as passed.
- Do not substitute compilation for behavior.
- Keep disposable data out of production.
