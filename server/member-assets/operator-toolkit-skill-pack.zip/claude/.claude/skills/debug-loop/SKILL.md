---
name: debug-loop
description: Runs a bounded evidence-first debugging loop. Use for errors, regressions, failing tests, or repeated unsuccessful fixes.
---

# Debug Loop

Category: Build + Quality

## Workflow

1. Reproduce the failure with the smallest reliable steps and capture the exact error.
2. Identify the last known working state and the narrowest likely ownership boundary.
3. Form one falsifiable hypothesis and choose one diagnostic check.
4. Make one minimal fix, then rerun the reproduction and relevant regressions.
5. After two failed fixes, stop, summarize evidence, and change the investigation strategy.

## Return

- Reproduction
- Evidence
- Hypothesis
- Fix
- Verification
- Remaining risk

## Guardrails

- No random dependency churn.
- No destructive cleanup commands.
- Do not stack unverified fixes.
