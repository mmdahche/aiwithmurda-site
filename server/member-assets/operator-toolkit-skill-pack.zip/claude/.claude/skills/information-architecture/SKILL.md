---
name: information-architecture
description: Organizes a dense interface around user intent and progressive disclosure. Use when a page feels chaotic, repetitive, or hard to navigate.
---

# Information Architecture

Category: Design + Product

## Workflow

1. Identify the primary user, top jobs, frequency, and most important next action.
2. Inventory content and classify it as essential now, contextual, reference, or administrative.
3. Remove duplication and define a small stable navigation model.
4. Sequence the default view around one decision or action and hide depth until requested.
5. Test labels and routes with realistic first-time and returning-user scenarios.

## Return

- User jobs
- Content inventory
- Navigation model
- Default hierarchy
- Progressive disclosure
- Test scenarios

## Guardrails

- Do not use cards as the only structure.
- Do not expose admin controls to customers.
- Do not hide critical status or recovery actions.
