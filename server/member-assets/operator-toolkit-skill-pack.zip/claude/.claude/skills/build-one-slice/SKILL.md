---
name: build-one-slice
description: Scopes and implements one small user-visible outcome. Use when a first version is needed or scope is expanding faster than proof.
---

# Build One Slice

Category: Foundation + Scope

## Workflow

1. Inspect the current user path and the smallest relevant ownership boundary.
2. Confirm the requested outcome, non-goals, verification, and stop condition.
3. Implement the narrowest vertical slice using existing project patterns.
4. Run focused checks and the real user path.
5. Stop when the agreed outcome passes and record deferred work separately.

## Return

- Approved slice
- Files changed
- Verification evidence
- Deferred work
- Next smallest slice

## Guardrails

- No unrelated refactors.
- No dependency additions without need and approval.
- Never call an untested path complete.
