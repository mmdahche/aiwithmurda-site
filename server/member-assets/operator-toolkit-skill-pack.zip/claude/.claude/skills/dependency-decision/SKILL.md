---
name: dependency-decision
description: Evaluates whether a library should be added. Use before installing packages for parsing, security, payments, archives, UI, or domain logic.
---

# Dependency Decision

Category: Build + Quality

## Workflow

1. Define the capability, complexity, security, performance, and maintenance requirements.
2. Check whether the project or standard platform already solves the need.
3. Compare viable maintained options using official sources and project compatibility.
4. Review license, release activity, dependency weight, API surface, and failure modes.
5. Choose, defer, or reject with an integration and removal plan.

## Return

- Need
- Options
- Tradeoffs
- Decision
- Integration plan
- Removal plan

## Guardrails

- Do not choose by popularity alone.
- Do not ignore licensing.
- Do not install before the decision is recorded.
