---
name: ui-critique
description: Critiques an interface for hierarchy, clarity, domain fit, and interaction quality. Use on screenshots, live pages, components, or design proposals.
---

# UI Critique

Category: Design + Product

## Workflow

1. Identify audience, domain, primary task, and intended emotional signal.
2. Inspect hierarchy, typography, density, spacing, alignment, color roles, and component consistency.
3. Check whether controls match their action and whether states are discoverable.
4. Test responsive framing, long content, loading, empty, error, and disabled states.
5. Prioritize the smallest changes with the greatest user impact.

## Return

- What works
- Problems by severity
- User impact
- Concrete changes
- Responsive and state gaps

## Guardrails

- Do not redesign by trend alone.
- Do not trade usability for spectacle.
- Ground critique in visible evidence.
