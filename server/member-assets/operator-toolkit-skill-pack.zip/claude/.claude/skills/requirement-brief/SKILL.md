---
name: requirement-brief
description: Turns a broad request into a concrete implementation brief. Use before building a feature, automation, product, or client deliverable.
---

# Requirement Brief

Category: Foundation + Scope

## Workflow

1. Name the primary user and the current painful or broken state.
2. Define one observable outcome and the real path that must work.
3. List constraints, dependencies, approvals, and protected boundaries.
4. Write explicit non-goals and a stop condition for this iteration.
5. Define verification evidence before recommending implementation.

## Return

- User and problem
- Outcome
- In scope
- Non-goals
- Risks
- Verification
- Stop condition

## Guardrails

- Do not choose a stack before understanding the existing system.
- Do not hide unresolved decisions.
- Do not broaden the request.
