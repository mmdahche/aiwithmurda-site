---
name: launch-checklist
description: Turns a product release into a verified operational launch. Use before opening checkout, publishing an offer, or starting a campaign.
---

# Launch Checklist

Category: Operations + Growth

## Workflow

1. Confirm the offer, inventory, pricing, renewal, ownership, support, and legal disclosure copy.
2. Test account creation, checkout, webhook, entitlement, email, download, and cancellation paths.
3. Verify analytics, attribution, support inbox, incident owner, and rollback controls.
4. Prepare launch content, proof, FAQ, objections, and recovery messages.
5. Run a rehearsal, capture receipts, and name every remaining human gate.

## Return

- Commercial readiness
- Technical readiness
- Operations
- Launch assets
- Rehearsal evidence
- Open gates

## Guardrails

- Do not launch untested billing.
- Do not expose private dashboards on stream.
- Do not treat a deployed page as a complete launch.
